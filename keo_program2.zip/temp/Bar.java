// import *;

class Bar{
    
    public void run(){
        int x = Foo.CONSTANT;
        
        Foo.Operation y = Foo.Operation.RUN;
    }
}