class Subject{
	
	
}